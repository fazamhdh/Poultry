import {Typography, Grid, Row, Col, Space} from "antd";

const Footer = () => {

    return (
        <div>
            <img src="./logo.png"></img>
        </div>
    )
}

export default Footer;