import styles from "./Header.module.scss";

const Header = () =>{

    return (
        <div>
            <img className={styles.header__img} src="./logo-header.png"></img>
            <h1>Testing</h1>
        </div>
    );
}

export default Header;