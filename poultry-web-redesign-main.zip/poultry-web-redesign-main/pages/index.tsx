import Layout from "@components/Commons/Layout";

const Home = () => {
    return (
        <Layout />
    );
};
export default Home;